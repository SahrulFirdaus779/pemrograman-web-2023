import aritmatika

aritmatika.tambah(1,5)
aritmatika.kali(2,4)
aritmatika.kurang(10,5)
aritmatika.bagi(9,3)
aritmatika.pangkat(3,3)
aritmatika.akar(10)
aritmatika.modulus(10,2)
aritmatika.pembagian_bulat(10,3)
aritmatika.cos(30)
aritmatika.tan(60)
aritmatika.sin(30)

#Bangun Datar
import bangun_datar

luas_persegi = bangun_datar.luas_persegi(10)
print("luas persegi adalah", luas_persegi)

keliling_persegi = bangun_datar.keliling_persegi(10)
print("keliling persegi adalah", keliling_persegi)

keliling_persegi_panjang = bangun_datar.keliling_persegi_panjang(2,10)
print("keliling persegi panjang =", keliling_persegi_panjang)

luas_persegi_panjang = bangun_datar.luas_persegi_panjang(2,10)
print("luas persegi panjang =", luas_persegi_panjang)

Keliling_segitiga = bangun_datar.keliling_segitiga(14,10,10)
print("keliling segitiga =", Keliling_segitiga)

luas_segitiga = bangun_datar.luas_segitiga(20,10)
print("luas segitiga =", luas_segitiga)

keliling_jajar_genjang = bangun_datar.keliling_jajargenjang(9,7)
print("keliling jajar genjang =", keliling_jajar_genjang)

luas_jajar_genjang = bangun_datar.luas_jajargenjang(99,33)
print("luas jajar genjang =", luas_jajar_genjang)

keliling_trapesium = bangun_datar.keliling_trapesium(10,20,10,20)
print("keliling trapesium =", keliling_trapesium)

luas_trapesium = bangun_datar.luas_trapesium(10,20,30)
print("luas trapesium =", luas_trapesium)

keliling_belah_ketupat = bangun_datar.keliling_belah_ketupat(35)
print("keliling belah ketupat =", keliling_belah_ketupat)

luas_belah_ketupat = bangun_datar.luas_belah_ketupat(9,9)
print("luas belah ketupat =", luas_belah_ketupat)

keliling_lingkaran = bangun_datar.keliling_lingkaran(17)
print("keliling lingkaran", keliling_lingkaran)

luas_lingkaran = bangun_datar.luas_lingkaran(17)
print("luas kelilig =", luas_lingkaran)





